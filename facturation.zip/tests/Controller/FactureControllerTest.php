<?php

namespace App\Test\Controller;

use App\Entity\Facture;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Symfony\Bundle\FrameworkBundle\KernelBrowser;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class FactureControllerTest extends WebTestCase
{
    private KernelBrowser $client;
    private EntityManagerInterface $manager;
    private EntityRepository $repository;
    private string $path = '/facture/';

    protected function setUp(): void
    {
        $this->client = static::createClient();
        $this->manager = static::getContainer()->get('doctrine')->getManager();
        $this->repository = $this->manager->getRepository(Facture::class);

        foreach ($this->repository->findAll() as $object) {
            $this->manager->remove($object);
        }

        $this->manager->flush();
    }

    public function testIndex(): void
    {
        $crawler = $this->client->request('GET', $this->path);

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('Facture index');

        // Use the $crawler to perform additional assertions e.g.
        // self::assertSame('Some text on the page', $crawler->filter('.p')->first());
    }

    public function testNew(): void
    {
        $this->markTestIncomplete();
        $this->client->request('GET', sprintf('%snew', $this->path));

        self::assertResponseStatusCodeSame(200);

        $this->client->submitForm('Save', [
            'facture[Quantite]' => 'Testing',
            'facture[Designation]' => 'Testing',
            'facture[Valeur]' => 'Testing',
            'facture[Prix_Unitaire]' => 'Testing',
            'facture[Prix_Total_ht]' => 'Testing',
            'facture[Transport]' => 'Testing',
            'facture[TVA]' => 'Testing',
            'facture[IR]' => 'Testing',
            'facture[Total_TTC]' => 'Testing',
            'facture[client]' => 'Testing',
            'facture[Moyen_paiement_id]' => 'Testing',
        ]);

        self::assertResponseRedirects($this->path);

        self::assertSame(1, $this->repository->count([]));
    }

    public function testShow(): void
    {
        $this->markTestIncomplete();
        $fixture = new Facture();
        $fixture->setQuantite('My Title');
        $fixture->setDesignation('My Title');
        $fixture->setValeur('My Title');
        $fixture->setPrix_Unitaire('My Title');
        $fixture->setPrix_Total_ht('My Title');
        $fixture->setTransport('My Title');
        $fixture->setTVA('My Title');
        $fixture->setIR('My Title');
        $fixture->setTotal_TTC('My Title');
        $fixture->setClient('My Title');
        $fixture->setMoyen_paiement_id('My Title');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('Facture');

        // Use assertions to check that the properties are properly displayed.
    }

    public function testEdit(): void
    {
        $this->markTestIncomplete();
        $fixture = new Facture();
        $fixture->setQuantite('Value');
        $fixture->setDesignation('Value');
        $fixture->setValeur('Value');
        $fixture->setPrix_Unitaire('Value');
        $fixture->setPrix_Total_ht('Value');
        $fixture->setTransport('Value');
        $fixture->setTVA('Value');
        $fixture->setIR('Value');
        $fixture->setTotal_TTC('Value');
        $fixture->setClient('Value');
        $fixture->setMoyen_paiement_id('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s/edit', $this->path, $fixture->getId()));

        $this->client->submitForm('Update', [
            'facture[Quantite]' => 'Something New',
            'facture[Designation]' => 'Something New',
            'facture[Valeur]' => 'Something New',
            'facture[Prix_Unitaire]' => 'Something New',
            'facture[Prix_Total_ht]' => 'Something New',
            'facture[Transport]' => 'Something New',
            'facture[TVA]' => 'Something New',
            'facture[IR]' => 'Something New',
            'facture[Total_TTC]' => 'Something New',
            'facture[client]' => 'Something New',
            'facture[Moyen_paiement_id]' => 'Something New',
        ]);

        self::assertResponseRedirects('/facture/');

        $fixture = $this->repository->findAll();

        self::assertSame('Something New', $fixture[0]->getQuantite());
        self::assertSame('Something New', $fixture[0]->getDesignation());
        self::assertSame('Something New', $fixture[0]->getValeur());
        self::assertSame('Something New', $fixture[0]->getPrix_Unitaire());
        self::assertSame('Something New', $fixture[0]->getPrix_Total_ht());
        self::assertSame('Something New', $fixture[0]->getTransport());
        self::assertSame('Something New', $fixture[0]->getTVA());
        self::assertSame('Something New', $fixture[0]->getIR());
        self::assertSame('Something New', $fixture[0]->getTotal_TTC());
        self::assertSame('Something New', $fixture[0]->getClient());
        self::assertSame('Something New', $fixture[0]->getMoyen_paiement_id());
    }

    public function testRemove(): void
    {
        $this->markTestIncomplete();
        $fixture = new Facture();
        $fixture->setQuantite('Value');
        $fixture->setDesignation('Value');
        $fixture->setValeur('Value');
        $fixture->setPrix_Unitaire('Value');
        $fixture->setPrix_Total_ht('Value');
        $fixture->setTransport('Value');
        $fixture->setTVA('Value');
        $fixture->setIR('Value');
        $fixture->setTotal_TTC('Value');
        $fixture->setClient('Value');
        $fixture->setMoyen_paiement_id('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));
        $this->client->submitForm('Delete');

        self::assertResponseRedirects('/facture/');
        self::assertSame(0, $this->repository->count([]));
    }
}
