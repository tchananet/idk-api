<?php

namespace App\Test\Controller;

use App\Entity\Stock;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Symfony\Bundle\FrameworkBundle\KernelBrowser;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class StockControllerTest extends WebTestCase
{
    private KernelBrowser $client;
    private EntityManagerInterface $manager;
    private EntityRepository $repository;
    private string $path = '/stock/contoller/';

    protected function setUp(): void
    {
        $this->client = static::createClient();
        $this->manager = static::getContainer()->get('doctrine')->getManager();
        $this->repository = $this->manager->getRepository(Stock::class);

        foreach ($this->repository->findAll() as $object) {
            $this->manager->remove($object);
        }

        $this->manager->flush();
    }

    public function testIndex(): void
    {
        $crawler = $this->client->request('GET', $this->path);

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('Stock index');

        // Use the $crawler to perform additional assertions e.g.
        // self::assertSame('Some text on the page', $crawler->filter('.p')->first());
    }

    public function testNew(): void
    {
        $this->markTestIncomplete();
        $this->client->request('GET', sprintf('%snew', $this->path));

        self::assertResponseStatusCodeSame(200);

        $this->client->submitForm('Save', [
            'stock[Date]' => 'Testing',
            'stock[KIT_GPS]' => 'Testing',
            'stock[Beneficiaire]' => 'Testing',
            'stock[Entrees]' => 'Testing',
            'stock[Sorties]' => 'Testing',
            'stock[Observation]' => 'Testing',
        ]);

        self::assertResponseRedirects($this->path);

        self::assertSame(1, $this->repository->count([]));
    }

    public function testShow(): void
    {
        $this->markTestIncomplete();
        $fixture = new Stock();
        $fixture->setDate('My Title');
        $fixture->setKIT_GPS('My Title');
        $fixture->setBeneficiaire('My Title');
        $fixture->setEntrees('My Title');
        $fixture->setSorties('My Title');
        $fixture->setObservation('My Title');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('Stock');

        // Use assertions to check that the properties are properly displayed.
    }

    public function testEdit(): void
    {
        $this->markTestIncomplete();
        $fixture = new Stock();
        $fixture->setDate('Value');
        $fixture->setKIT_GPS('Value');
        $fixture->setBeneficiaire('Value');
        $fixture->setEntrees('Value');
        $fixture->setSorties('Value');
        $fixture->setObservation('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s/edit', $this->path, $fixture->getId()));

        $this->client->submitForm('Update', [
            'stock[Date]' => 'Something New',
            'stock[KIT_GPS]' => 'Something New',
            'stock[Beneficiaire]' => 'Something New',
            'stock[Entrees]' => 'Something New',
            'stock[Sorties]' => 'Something New',
            'stock[Observation]' => 'Something New',
        ]);

        self::assertResponseRedirects('/stock/contoller/');

        $fixture = $this->repository->findAll();

        self::assertSame('Something New', $fixture[0]->getDate());
        self::assertSame('Something New', $fixture[0]->getKIT_GPS());
        self::assertSame('Something New', $fixture[0]->getBeneficiaire());
        self::assertSame('Something New', $fixture[0]->getEntrees());
        self::assertSame('Something New', $fixture[0]->getSorties());
        self::assertSame('Something New', $fixture[0]->getObservation());
    }

    public function testRemove(): void
    {
        $this->markTestIncomplete();
        $fixture = new Stock();
        $fixture->setDate('Value');
        $fixture->setKIT_GPS('Value');
        $fixture->setBeneficiaire('Value');
        $fixture->setEntrees('Value');
        $fixture->setSorties('Value');
        $fixture->setObservation('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));
        $this->client->submitForm('Delete');

        self::assertResponseRedirects('/stock/contoller/');
        self::assertSame(0, $this->repository->count([]));
    }
}
