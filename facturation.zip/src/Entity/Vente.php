<?php

namespace App\Entity;

use App\Repository\VenteRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: VenteRepository::class)]
class Vente
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $Date = null;

    #[ORM\ManyToOne(inversedBy: 'ventes')]
    private ?Client $ClientID = null;

    #[ORM\Column]
    private ?int $Telephone = null;

    #[ORM\Column(length: 255)]
    private ?string $Localisation = null;

    #[ORM\Column(length: 255)]
    private ?string $Immatriculation = null;

    #[ORM\Column]
    private ?int $Kit_GPS = null;

    #[ORM\Column]
    private ?int $Numero_Puce = null;

    #[ORM\Column(length: 50)]
    private ?string $IMEI = null;

    #[ORM\Column(length: 255)]
    private ?string $Vendeur = null;

    #[ORM\Column(length: 255)]
    private ?string $Type_Vente = null;

    #[ORM\Column]
    private ?int $Quantite = null;

    #[ORM\Column(type: Types::DECIMAL, precision: 10, scale: 2)]
    private ?string $Montant = null;

    #[ORM\Column(type: Types::DECIMAL, precision: 10, scale: 2)]
    private ?string $Avance = null;

    #[ORM\Column(type: Types::DECIMAL, precision: 10, scale: 2)]
    private ?string $Reliquat = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $Observation = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(\DateTimeInterface $Date): static
    {
        $this->Date = $Date;

        return $this;
    }

    public function getClientID(): ?Client
    {
        return $this->ClientID;
    }

    public function setClientID(?Client $ClientID): static
    {
        $this->ClientID = $ClientID;

        return $this;
    }

    public function getTelephone(): ?int
    {
        return $this->Telephone;
    }

    public function setTelephone(int $Telephone): static
    {
        $this->Telephone = $Telephone;

        return $this;
    }

    public function getLocalisation(): ?string
    {
        return $this->Localisation;
    }

    public function setLocalisation(string $Localisation): static
    {
        $this->Localisation = $Localisation;

        return $this;
    }

    public function getImmatriculation(): ?string
    {
        return $this->Immatriculation;
    }

    public function setImmatriculation(string $Immatriculation): static
    {
        $this->Immatriculation = $Immatriculation;

        return $this;
    }

    public function getKitGPS(): ?int
    {
        return $this->Kit_GPS;
    }

    public function setKitGPS(int $Kit_GPS): static
    {
        $this->Kit_GPS = $Kit_GPS;

        return $this;
    }

    public function getNumeroPuce(): ?int
    {
        return $this->Numero_Puce;
    }

    public function setNumeroPuce(int $Numero_Puce): static
    {
        $this->Numero_Puce = $Numero_Puce;

        return $this;
    }

    public function getIMEI(): ?string
    {
        return $this->IMEI;
    }

    public function setIMEI(string $IMEI): static
    {
        $this->IMEI = $IMEI;

        return $this;
    }

    public function getVendeur(): ?string
    {
        return $this->Vendeur;
    }

    public function setVendeur(string $Vendeur): static
    {
        $this->Vendeur = $Vendeur;

        return $this;
    }

    public function getTypeVente(): ?string
    {
        return $this->Type_Vente;
    }

    public function setTypeVente(string $Type_Vente): static
    {
        $this->Type_Vente = $Type_Vente;

        return $this;
    }

    public function getQuantite(): ?int
    {
        return $this->Quantite;
    }

    public function setQuantite(int $Quantite): static
    {
        $this->Quantite = $Quantite;

        return $this;
    }

    public function getMontant(): ?string
    {
        return $this->Montant;
    }

    public function setMontant(string $Montant): static
    {
        $this->Montant = $Montant;

        return $this;
    }

    public function getAvance(): ?string
    {
        return $this->Avance;
    }

    public function setAvance(string $Avance): static
    {
        $this->Avance = $Avance;

        return $this;
    }

    public function getReliquat(): ?string
    {
        return $this->Reliquat;
    }

    public function setReliquat(string $Reliquat): static
    {
        $this->Reliquat = $Reliquat;

        return $this;
    }

    public function getObservation(): ?string
    {
        return $this->Observation;
    }

    public function setObservation(string $Observation): static
    {
        $this->Observation = $Observation;

        return $this;
    }

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    // Ajoutez les autres propriétés et annotations ORM nécessaires

    // Définition de la méthode getName
    public function getName(): ?string
    {
        return $this->name;
    }

    // Définition de la méthode setName
    public function setName(string $name): self
    {
        $this->name = $name;
        return $this;
    }
}
