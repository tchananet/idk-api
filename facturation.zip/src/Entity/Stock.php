<?php

namespace App\Entity;

use App\Repository\StockRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: StockRepository::class)]
class Stock
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $Date = null;

    #[ORM\Column(length: 255)]
    private ?string $Beneficiaire = null;

    #[ORM\Column]
    private ?int $Entrees = null;

    #[ORM\Column]
    private ?int $Sorties = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $Observation = null;

    #[ORM\ManyToOne(targetEntity: self::class, inversedBy: 'Produit')]
    private ?self $stock = null;

    #[ORM\OneToMany(targetEntity: self::class, mappedBy: 'stock')]
    private Collection $Produit;

    public function __construct()
    {
        $this->Produit = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(\DateTimeInterface $Date): static
    {
        $this->Date = $Date;

        return $this;
    }

    public function getBeneficiaire(): ?string
    {
        return $this->Beneficiaire;
    }

    public function setBeneficiaire(string $Beneficiaire): static
    {
        $this->Beneficiaire = $Beneficiaire;

        return $this;
    }

    public function getEntrees(): ?int
    {
        return $this->Entrees;
    }

    public function setEntrees(int $Entrees): static
    {
        $this->Entrees = $Entrees;

        return $this;
    }

    public function getSorties(): ?int
    {
        return $this->Sorties;
    }

    public function setSorties(int $Sorties): static
    {
        $this->Sorties = $Sorties;

        return $this;
    }

    public function getObservation(): ?string
    {
        return $this->Observation;
    }

    public function setObservation(string $Observation): static
    {
        $this->Observation = $Observation;

        return $this;
    }

    public function getStock(): ?self
    {
        return $this->stock;
    }

    public function setStock(?self $stock): static
    {
        $this->stock = $stock;

        return $this;
    }

    /**
     * @return Collection<int, self>
     */
    public function getProduit(): Collection
    {
        return $this->Produit;
    }

    public function addProduit(self $produit): static
    {
        if (!$this->Produit->contains($produit)) {
            $this->Produit->add($produit);
            $produit->setStock($this);
        }

        return $this;
    }

    public function removeProduit(self $produit): static
    {
        if ($this->Produit->removeElement($produit)) {
            // set the owning side to null (unless already changed)
            if ($produit->getStock() === $this) {
                $produit->setStock(null);
            }
        }

        return $this;
    }

}
