<?php

namespace App\Entity;

use App\Repository\InventaireRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: InventaireRepository::class)]
class Inventaire
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Description = null;

    #[ORM\Column]
    private ?string $Entree = null;

    #[ORM\Column]
    private ?string $Sortie = null;

    #[ORM\Column]
    private ?string $SI = null;

    #[ORM\Column]
    private ?string $SF = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $Observation = null;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDescription(): ?string
    {
        return $this->Description;
    }

    public function setDescription(string $Description): static
    {
        $this->Description = $Description;

        return $this;
    }

    public function getEntree(): ?string
    {
        return $this->Entree;
    }

    public function setEntree(string $Entree): static
    {
        $this->Entree = $Entree;

        return $this;
    }

    public function getSortie(): ?string
    {
        return $this->Sortie;
    }

    public function setSortie(string $Sortie): static
    {
        $this->Sortie = $Sortie;

        return $this;
    }

    public function getSI(): ?string
    {
        return $this->SI;
    }

    public function setSI(string $SI): static
    {
        $this->SI = $SI;

        return $this;
    }

    public function getSF(): ?string
    {
        return $this->SF;
    }

    public function setSF(string $SF): static
    {
        $this->SF = $SF;

        return $this;
    }

    public function getObservation(): ?string
    {
        return $this->Observation;
    }

    public function setObservation(string $Observation): static
    {
        $this->Observation = $Observation;

        return $this;
    }
}
