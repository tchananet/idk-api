<?php

namespace App\Controller;

use App\Entity\Produit;
use App\Entity\Stock;
use App\Repository\ProduitRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/produit')]
class ProduitController extends AbstractController
{
    private $validator;

    public function __construct(ValidatorInterface $validator)
    {
        $this->validator = $validator;
    }

    #[Route('/', name: 'app_produit_index', methods: ['GET'])]
    public function index(ProduitRepository $produitRepository, SerializerInterface $serializer): Response
    {
        $produits = $produitRepository->findAll();
        $formattedProducts = array_map(function($produit) {
            $quantity = $produit->getStockId() ? $produit->getStockId()->getEntrees() - $produit->getStockId()->getSorties() : 0;
            $status = $this->determineStatus($quantity);
            return [
                'Nom' => $produit->getNom(),
                'SKU' => $produit->getSku(),
                'Catégorie' => $produit->getCategorie(),
                'Prix' => $produit->getPrixUnitaire(),
                'Quantité' => $quantity,
                'Statut' => $status,
            ];
        }, $produits);

        $data = $serializer->serialize($formattedProducts, 'json');

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    private function determineStatus(int $quantity): string
    {
        if ($quantity == 0) {
            return 'épuisé';
        } elseif ($quantity < 10) {
            return 'stock limité';
        } elseif ($quantity < 20) {
            return 'pré-commande';
        } else {
            return 'en stock';
        }
    }

    #[Route('/new', name: 'app_produit_new', methods: ['POST'])]
public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
{
    $jsonData = $request->getContent();
    $data = json_decode($jsonData, true);

    // Vérification que les clés existent dans les données JSON
    if (!isset($data['nom'], $data['categorie'], $data['prixUnitaire'], $data['stock_id'])) {
        return new Response('Les clés "nom", "categorie", "prixUnitaire" et "stock_id" sont requises dans les données JSON.', Response::HTTP_BAD_REQUEST);
    }

    $produit = new Produit();
    $produit->setNom($data['nom']);
    $produit->setCategorie($data['categorie']);
    $produit->setPrixUnitaire($data['prixUnitaire']);

    // Rechercher l'entité Stock correspondante
    $stock = $entityManager->getRepository(Stock::class)->find($data['stock_id']);
    if (!$stock) {
        return new Response('Le stock avec cet identifiant n\'existe pas.', Response::HTTP_BAD_REQUEST);
    }
    $produit->setStockId($stock);

    // Générer automatiquement le SKU
    $produit->setSkuAutomatically();

    // Validation des contraintes de l'entité Produit
    $errors = $validator->validate($produit);
    if (count($errors) > 0) {
        $errorsString = (string) $errors;
        return new Response($errorsString, Response::HTTP_BAD_REQUEST);
    }

    $entityManager->persist($produit);
    $entityManager->flush();

    $quantity = $stock->getEntrees() - $stock->getSorties();
    $status = $this->determineStatus($quantity);

    $response = [
        'Nom' => $produit->getNom(),
        'SKU' => $produit->getSku(),
        'Catégorie' => $produit->getCategorie(),
        'Prix' => $produit->getPrixUnitaire(),
        'Quantité' => $quantity,
        'Statut' => $status,
    ];

    return new Response($serializer->serialize($response, 'json'), Response::HTTP_CREATED, [
        'Content-Type' => 'application/json'
    ]);
}

#[Route('/{id}', name: 'app_produit_show', methods: ['GET'])]
public function show(Produit $produit, SerializerInterface $serializer): Response
{
    $quantity = $produit->getStockId() ? $produit->getStockId()->getEntrees() - $produit->getStockId()->getSorties() : 0;
    $status = $this->determineStatus($quantity);

    $formattedProduct = [
        'Nom' => $produit->getNom(),
        'SKU' => $produit->getSku(),
        'Catégorie' => $produit->getCategorie(),
        'Prix' => $produit->getPrixUnitaire(),
        'Quantité' => $quantity,
        'Statut' => $status,
    ];

    $data = $serializer->serialize($formattedProduct, 'json');

    return new Response($data, 200, [
        'Content-Type' => 'application/json'
    ]);
}

#[Route('/{id}/edit', name: 'app_produit_edit', methods: ['PUT', 'PATCH'])]
public function edit(Request $request, Produit $produit, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
{
    $jsonData = $request->getContent();
    $data = json_decode($jsonData, true);

    // Vérification que les clés existent dans les données JSON
    if (!isset($data['nom'], $data['categorie'], $data['prixUnitaire'], $data['stock_id'])) {
        return new Response('Les clés "nom", "categorie", "prixUnitaire" et "stock_id" sont requises dans les données JSON.', Response::HTTP_BAD_REQUEST);
    }

    $produit->setNom($data['nom']);
    $produit->setCategorie($data['categorie']);
    $produit->setPrixUnitaire($data['prixUnitaire']);

    // Rechercher l'entité Stock correspondante
    $stock = $entityManager->getRepository(Stock::class)->find($data['stock_id']);
    if (!$stock) {
        return new Response('Le stock avec cet identifiant n\'existe pas.', Response::HTTP_BAD_REQUEST);
    }
    $produit->setStockId($stock);

    // Validation des contraintes de l'entité Produit
    $errors = $validator->validate($produit);
    if (count($errors) > 0) {
        $errorsString = (string) $errors;
        return new Response($errorsString, Response::HTTP_BAD_REQUEST);
    }

    $entityManager->flush();

    $quantity = $stock->getEntrees() - $stock->getSorties();
    $status = $this->determineStatus($quantity);

    $response = [
        'Nom' => $produit->getNom(),
        'SKU' => $produit->getSku(),
        'Catégorie' => $produit->getCategorie(),
        'Prix' => $produit->getPrixUnitaire(),
        'Quantité' => $quantity,
        'Statut' => $status,
    ];

    return new Response($serializer->serialize($response, 'json'), Response::HTTP_OK, [
        'Content-Type' => 'application/json'
    ]);
}


    #[Route('/{id}', name: 'app_produit_delete', methods: ['DELETE'])]
    public function delete(Produit $produit, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        $entityManager->remove($produit);
        $entityManager->flush();

        $response = [
            'Nom' => $produit->getNom(),
            'SKU' => $produit->getSku(),
            'Catégorie' => $produit->getCategorie(),
            'Prix' => $produit->getPrixUnitaire(),
        ];

        return new Response($serializer->serialize($response, 'json'), Response::HTTP_NO_CONTENT, [
            'Content-Type' => 'application/json'
        ]);
    }
}
