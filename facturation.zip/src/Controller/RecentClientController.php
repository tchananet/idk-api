<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Client;

class RecentClientController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/recent/client', name: 'app_recent_client')]
    public function index(): JsonResponse
    {
        // Get the 10 most recent clients
        $recentClients = $this->getRecentClients(10);

        return new JsonResponse($recentClients);
    }

    private function getRecentClients(int $limit): array
    {
        $clients = $this->entityManager->getRepository(Client::class)->findBy([], ['createdAt' => 'DESC'], $limit);

        return array_map(function($client) {
            return [
                'id' => $client->getId(),
                'name' => $client->getNom(),
            ];
        }, $clients);
    }
}
