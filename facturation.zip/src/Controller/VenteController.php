<?php

namespace App\Controller;

use App\Entity\Vente;
use App\Entity\Client;
use App\Repository\VenteRepository;
use App\Repository\ClientRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;

#[Route('/vente')]
class VenteController extends AbstractController
{
    #[Route('/', name: 'app_vente_index', methods: ['GET'])]
    public function index(VenteRepository $venteRepository, SerializerInterface $serializer): Response
    {
        $ventes = $venteRepository->findAll();
        $formattedVentes = array_map(function($vente) {
            return [
                'id' => $vente->getId(),
                'Date' => $vente->getDate()->format('Y-m-d'),
                'ClientID' => $vente->getClientID()->getId(),
                'Telephone' => $vente->getTelephone(),
                'Localisation' => $vente->getLocalisation(),
                'Immatriculation' => $vente->getImmatriculation(),
                'Kit_GPS' => $vente->getKitGPS(),
                'Numero_Puce' => $vente->getNumeroPuce(),
                'IMEI' => $vente->getIMEI(),
                'Vendeur' => $vente->getVendeur(),
                'Type_Vente' => $vente->getTypeVente(),
                'Quantite' => $vente->getQuantite(),
                'Montant' => $vente->getMontant(),
                'Avance' => $vente->getAvance(),
                'Reliquat' => $vente->getReliquat(),
                'Observation' => $vente->getObservation(),
            ];
        }, $ventes);

        $data = $serializer->serialize($formattedVentes, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/new', name: 'app_vente_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, ClientRepository $clientRepository, SerializerInterface $serializer): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        // Récupération de l'entité Client
        $client = $clientRepository->find($data['ClientID']);
        if (!$client) {
            return $this->json(['error' => 'Client not found'], Response::HTTP_NOT_FOUND);
        }

        // Création d'un nouvel objet Vente et attribution des données reçues
        $vente = new Vente();
        $vente->setDate(new \DateTime($data['Date']));
        $vente->setClientID($client);
        $vente->setTelephone($data['Telephone']);
        $vente->setLocalisation($data['Localisation']);
        $vente->setImmatriculation($data['Immatriculation']);
        $vente->setKitGPS($data['Kit_GPS']);
        $vente->setNumeroPuce($data['Numero_Puce']);
        $vente->setIMEI($data['IMEI']);
        $vente->setVendeur($data['Vendeur']);
        $vente->setTypeVente($data['Type_Vente']);
        $vente->setQuantite($data['Quantite']);
        $vente->setMontant($data['Montant']);
        $vente->setAvance($data['Avance']);
        $vente->setReliquat($data['Reliquat']);
        $vente->setObservation($data['Observation']);

        // Insertion de l'objet vente dans la base de données
        $entityManager->persist($vente);
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec les détails de la nouvelle vente créée
        return $this->json([
            'id' => $vente->getId(),
            'Date' => $vente->getDate()->format('Y-m-d'),
            'ClientID' => $vente->getClientID()->getId(),
            'Telephone' => $vente->getTelephone(),
            'Localisation' => $vente->getLocalisation(),
            'Immatriculation' => $vente->getImmatriculation(),
            'Kit_GPS' => $vente->getKitGPS(),
            'Numero_Puce' => $vente->getNumeroPuce(),
            'IMEI' => $vente->getIMEI(),
            'Vendeur' => $vente->getVendeur(),
            'Type_Vente' => $vente->getTypeVente(),
            'Quantite' => $vente->getQuantite(),
            'Montant' => $vente->getMontant(),
            'Avance' => $vente->getAvance(),
            'Reliquat' => $vente->getReliquat(),
            'Observation' => $vente->getObservation()
        ], Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_vente_show', methods: ['GET'])]
    public function show(Vente $vente): Response
    {
        return $this->json([
            'id' => $vente->getId(),
            'Date' => $vente->getDate()->format('Y-m-d'),
            'ClientID' => $vente->getClientID()->getId(),
            'Telephone' => $vente->getTelephone(),
            'Localisation' => $vente->getLocalisation(),
            'Immatriculation' => $vente->getImmatriculation(),
            'Kit_GPS' => $vente->getKitGPS(),
            'Numero_Puce' => $vente->getNumeroPuce(),
            'IMEI' => $vente->getIMEI(),
            'Vendeur' => $vente->getVendeur(),
            'Type_Vente' => $vente->getTypeVente(),
            'Quantite' => $vente->getQuantite(),
            'Montant' => $vente->getMontant(),
            'Avance' => $vente->getAvance(),
            'Reliquat' => $vente->getReliquat(),
            'Observation' => $vente->getObservation(),
        ]);
    }

    #[Route('/{id}/edit', name: 'app_vente_edit', methods: ['PUT', 'PATCH'])]
    public function edit(Request $request, Vente $vente, EntityManagerInterface $entityManager, ClientRepository $clientRepository, SerializerInterface $serializer): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        // Récupération de l'entité Client
        if (isset($data['ClientID'])) {
            $client = $clientRepository->find($data['ClientID']);
            if (!$client) {
                return $this->json(['error' => 'Client not found'], Response::HTTP_NOT_FOUND);
            }
            $vente->setClientID($client);
        }

        // Mise à jour de l'objet Vente avec les nouvelles données
        $vente->setDate(new \DateTime($data['Date']));
        $vente->setTelephone($data['Telephone']);
        $vente->setLocalisation($data['Localisation']);
        $vente->setImmatriculation($data['Immatriculation']);
        $vente->setKitGPS($data['Kit_GPS']);
        $vente->setNumeroPuce($data['Numero_Puce']);
        $vente->setIMEI($data['IMEI']);
        $vente->setVendeur($data['Vendeur']);
        $vente->setTypeVente($data['Type_Vente']);
        $vente->setQuantite($data['Quantite']);
        $vente->setMontant($data['Montant']);
        $vente->setAvance($data['Avance']);
        $vente->setReliquat($data['Reliquat']);
        $vente->setObservation($data['Observation']);

        // Mise à jour de la vente dans la base de données
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec un message de succès
        return $this->json(['message' => 'Vente modifiée avec succès']);
    }

    #[Route('/{id}', name: 'app_vente_delete', methods: ['DELETE'])]
    public function delete(Vente $vente, EntityManagerInterface $entityManager): Response
    {
        // Suppression de la vente de la base de données
        $entityManager->remove($vente);
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec un message de succès
        return $this->json(['message' => 'Vente supprimée avec succès'], Response::HTTP_NO_CONTENT);
    }
}
