<?php

namespace App\Controller;

use App\Entity\Client;
use App\Entity\Facture;
use App\Entity\FactureProduit;
use App\Entity\Produit;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class FactureController extends AbstractController
{
    #[Route('/facture/new', name: 'app_facture_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $client = $entityManager->getRepository(Client::class)->find($data['client_id']);
        if (!$client) {
            return new JsonResponse(['message' => 'Client not found'], JsonResponse::HTTP_BAD_REQUEST);
        }

        $facture = new Facture();
        $facture->setClient($client);
        $facture->setMoyenPaiement($data['moyenPaiement']);
        $facture->setDate(new \DateTime());

        $totalHT = 0;

        foreach ($data['produits'] as $produitData) {
            $produit = $entityManager->getRepository(Produit::class)->find($produitData['id']);
            if (!$produit) {
                return new JsonResponse(['message' => 'Produit not found'], JsonResponse::HTTP_BAD_REQUEST);
            }

            $factureProduit = new FactureProduit();
            $factureProduit->setProduit($produit);
            $factureProduit->setQuantite($produitData['quantite']);
            $factureProduit->setPrixUnitaire($produit->getPrixUnitaire());
            $factureProduit->setTotal($produitData['quantite'] * $produit->getPrixUnitaire());
            $factureProduit->setObservation($produitData['observation']);
            $facture->addProduit($factureProduit);

            $totalHT += $factureProduit->getTotal();
        }

        $facture->setTotalHT($totalHT);
        $tva = $totalHT * 0.1925;
        $ir = $totalHT * 0.02;
        $totalTTC = $totalHT + $tva + $ir;

        $facture->setTva($tva);
        $facture->setIr($ir);
        $facture->setTotalTTC($totalTTC);
        $facture->setNumeroFacture('F' . time()); // Générer un numéro de facture unique

        $entityManager->persist($facture);
        $entityManager->flush();

        return new JsonResponse(['message' => 'Facture créée avec succès'], JsonResponse::HTTP_CREATED);
    }

    #[Route('/facture/{id}', name: 'app_facture_show', methods: ['GET'])]
    public function show(Facture $facture): JsonResponse
    {
        $data = [
            'clientNom' => $facture->getClient()->getNom(),
            'clientPrenom' => $facture->getClient()->getPrenom(),
            'clientAdresse' => $facture->getClient()->getAdresse(),
            'clientTelephone' => $facture->getClient()->getTelephone(),
            'moyenPaiement' => $facture->getMoyenPaiement(),
            'date' => $facture->getDate()->format('Y-m-d H:i:s'),
            'numeroFacture' => $facture->getNumeroFacture(),
            'totalHT' => $facture->getTotalHT(),
            'tva' => $facture->getTva(),
            'ir' => $facture->getIr(),
            'totalTTC' => $facture->getTotalTTC(),
            'produits' => []
        ];

        foreach ($facture->getProduits() as $factureProduit) {
            $data['produits'][] = [
                'nomProduit' => $factureProduit->getProduit()->getNom(),
                'quantite' => $factureProduit->getQuantite(),
                'prixUnitaire' => $factureProduit->getPrixUnitaire(),
                'total' => $factureProduit->getTotal(),
                'observation' => $factureProduit->getObservation(),
            ];
        }

        return new JsonResponse($data);
    }
}
