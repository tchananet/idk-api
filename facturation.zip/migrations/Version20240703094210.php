<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240703094210 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE brouillard_caisse (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, numero VARCHAR(255) NOT NULL, date DATE NOT NULL, libelles VARCHAR(255) NOT NULL, tiers VARCHAR(255) NOT NULL, entree INTEGER NOT NULL, sorties INTEGER NOT NULL, solde INTEGER NOT NULL, observation CLOB DEFAULT NULL)');
        $this->addSql('CREATE TABLE client (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, telephone VARCHAR(20) NOT NULL)');
        $this->addSql('CREATE TABLE facture (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, client_id INTEGER NOT NULL, moyen_paiement VARCHAR(255) NOT NULL, date DATETIME NOT NULL, total_ht DOUBLE PRECISION NOT NULL, tva DOUBLE PRECISION NOT NULL, ir DOUBLE PRECISION NOT NULL, total_ttc DOUBLE PRECISION NOT NULL, numero_facture VARCHAR(255) NOT NULL, CONSTRAINT FK_FE86641019EB6921 FOREIGN KEY (client_id) REFERENCES client (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_FE86641019EB6921 ON facture (client_id)');
        $this->addSql('CREATE TABLE facture_produit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, facture_id INTEGER DEFAULT NULL, produit_id INTEGER DEFAULT NULL, quantite INTEGER NOT NULL, prix_unitaire NUMERIC(20, 2) NOT NULL, total NUMERIC(20, 2) NOT NULL, observation CLOB DEFAULT NULL, CONSTRAINT FK_61424D7E7F2DEE08 FOREIGN KEY (facture_id) REFERENCES facture (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_61424D7EF347EFB FOREIGN KEY (produit_id) REFERENCES produit (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_61424D7E7F2DEE08 ON facture_produit (facture_id)');
        $this->addSql('CREATE INDEX IDX_61424D7EF347EFB ON facture_produit (produit_id)');
        $this->addSql('CREATE TABLE inventaire (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, description VARCHAR(255) NOT NULL, entree VARCHAR(255) NOT NULL, sortie VARCHAR(255) NOT NULL, si VARCHAR(255) NOT NULL, sf VARCHAR(255) NOT NULL, observation CLOB NOT NULL)');
        $this->addSql('CREATE TABLE moyen_paiement (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL)');
        $this->addSql('CREATE TABLE paiement (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, commentaire CLOB NOT NULL, nom VARCHAR(255) NOT NULL)');
        $this->addSql('CREATE TABLE produit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, stock_id_id INTEGER DEFAULT NULL, nom VARCHAR(255) DEFAULT NULL, sku VARCHAR(255) NOT NULL, prix_unitaire NUMERIC(20, 2) DEFAULT NULL, categorie VARCHAR(255) DEFAULT NULL, CONSTRAINT FK_29A5EC27E35482A6 FOREIGN KEY (stock_id_id) REFERENCES stock (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_29A5EC27F9038C4 ON produit (sku)');
        $this->addSql('CREATE INDEX IDX_29A5EC27E35482A6 ON produit (stock_id_id)');
        $this->addSql('CREATE TABLE stock (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, stock_id INTEGER DEFAULT NULL, date DATE NOT NULL, beneficiaire VARCHAR(255) NOT NULL, entrees INTEGER NOT NULL, sorties INTEGER NOT NULL, observation CLOB NOT NULL, CONSTRAINT FK_4B365660DCD6110 FOREIGN KEY (stock_id) REFERENCES stock (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_4B365660DCD6110 ON stock (stock_id)');
        $this->addSql('CREATE TABLE vente (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, client_id_id INTEGER DEFAULT NULL, date DATE NOT NULL, telephone INTEGER NOT NULL, localisation VARCHAR(255) NOT NULL, immatriculation VARCHAR(255) NOT NULL, kit_gps INTEGER NOT NULL, numero_puce INTEGER NOT NULL, imei VARCHAR(50) NOT NULL, vendeur VARCHAR(255) NOT NULL, type_vente VARCHAR(255) NOT NULL, quantite INTEGER NOT NULL, montant NUMERIC(10, 2) NOT NULL, avance NUMERIC(10, 2) NOT NULL, reliquat NUMERIC(10, 2) NOT NULL, observation CLOB NOT NULL, CONSTRAINT FK_888A2A4CDC2902E0 FOREIGN KEY (client_id_id) REFERENCES client (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_888A2A4CDC2902E0 ON vente (client_id_id)');
        $this->addSql('CREATE TABLE messenger_messages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, body CLOB NOT NULL, headers CLOB NOT NULL, queue_name VARCHAR(190) NOT NULL, created_at DATETIME NOT NULL --(DC2Type:datetime_immutable)
        , available_at DATETIME NOT NULL --(DC2Type:datetime_immutable)
        , delivered_at DATETIME DEFAULT NULL --(DC2Type:datetime_immutable)
        )');
        $this->addSql('CREATE INDEX IDX_75EA56E0FB7336F0 ON messenger_messages (queue_name)');
        $this->addSql('CREATE INDEX IDX_75EA56E0E3BD61CE ON messenger_messages (available_at)');
        $this->addSql('CREATE INDEX IDX_75EA56E016BA31DB ON messenger_messages (delivered_at)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE brouillard_caisse');
        $this->addSql('DROP TABLE client');
        $this->addSql('DROP TABLE facture');
        $this->addSql('DROP TABLE facture_produit');
        $this->addSql('DROP TABLE inventaire');
        $this->addSql('DROP TABLE moyen_paiement');
        $this->addSql('DROP TABLE paiement');
        $this->addSql('DROP TABLE produit');
        $this->addSql('DROP TABLE stock');
        $this->addSql('DROP TABLE vente');
        $this->addSql('DROP TABLE messenger_messages');
    }
}
