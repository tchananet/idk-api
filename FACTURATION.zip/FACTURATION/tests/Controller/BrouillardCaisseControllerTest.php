<?php

namespace App\Test\Controller;

use App\Entity\BrouillardCaisse;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Symfony\Bundle\FrameworkBundle\KernelBrowser;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class BrouillardCaisseControllerTest extends WebTestCase
{
    private KernelBrowser $client;
    private EntityManagerInterface $manager;
    private EntityRepository $repository;
    private string $path = '/brouillard/caisse/';

    protected function setUp(): void
    {
        $this->client = static::createClient();
        $this->manager = static::getContainer()->get('doctrine')->getManager();
        $this->repository = $this->manager->getRepository(BrouillardCaisse::class);

        foreach ($this->repository->findAll() as $object) {
            $this->manager->remove($object);
        }

        $this->manager->flush();
    }

    public function testIndex(): void
    {
        $crawler = $this->client->request('GET', $this->path);

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('BrouillardCaisse index');

        // Use the $crawler to perform additional assertions e.g.
        // self::assertSame('Some text on the page', $crawler->filter('.p')->first());
    }

    public function testNew(): void
    {
        $this->markTestIncomplete();
        $this->client->request('GET', sprintf('%snew', $this->path));

        self::assertResponseStatusCodeSame(200);

        $this->client->submitForm('Save', [
            'brouillard_caisse[Numero]' => 'Testing',
            'brouillard_caisse[Date]' => 'Testing',
            'brouillard_caisse[Libelles]' => 'Testing',
            'brouillard_caisse[Tiers]' => 'Testing',
            'brouillard_caisse[Entree]' => 'Testing',
            'brouillard_caisse[Sorties]' => 'Testing',
            'brouillard_caisse[Solde]' => 'Testing',
            'brouillard_caisse[Observation]' => 'Testing',
        ]);

        self::assertResponseRedirects($this->path);

        self::assertSame(1, $this->repository->count([]));
    }

    public function testShow(): void
    {
        $this->markTestIncomplete();
        $fixture = new BrouillardCaisse();
        $fixture->setNumero('My Title');
        $fixture->setDate('My Title');
        $fixture->setLibelles('My Title');
        $fixture->setTiers('My Title');
        $fixture->setEntree('My Title');
        $fixture->setSorties('My Title');
        $fixture->setSolde('My Title');
        $fixture->setObservation('My Title');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));

        self::assertResponseStatusCodeSame(200);
        self::assertPageTitleContains('BrouillardCaisse');

        // Use assertions to check that the properties are properly displayed.
    }

    public function testEdit(): void
    {
        $this->markTestIncomplete();
        $fixture = new BrouillardCaisse();
        $fixture->setNumero('Value');
        $fixture->setDate('Value');
        $fixture->setLibelles('Value');
        $fixture->setTiers('Value');
        $fixture->setEntree('Value');
        $fixture->setSorties('Value');
        $fixture->setSolde('Value');
        $fixture->setObservation('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s/edit', $this->path, $fixture->getId()));

        $this->client->submitForm('Update', [
            'brouillard_caisse[Numero]' => 'Something New',
            'brouillard_caisse[Date]' => 'Something New',
            'brouillard_caisse[Libelles]' => 'Something New',
            'brouillard_caisse[Tiers]' => 'Something New',
            'brouillard_caisse[Entree]' => 'Something New',
            'brouillard_caisse[Sorties]' => 'Something New',
            'brouillard_caisse[Solde]' => 'Something New',
            'brouillard_caisse[Observation]' => 'Something New',
        ]);

        self::assertResponseRedirects('/brouillard/caisse/');

        $fixture = $this->repository->findAll();

        self::assertSame('Something New', $fixture[0]->getNumero());
        self::assertSame('Something New', $fixture[0]->getDate());
        self::assertSame('Something New', $fixture[0]->getLibelles());
        self::assertSame('Something New', $fixture[0]->getTiers());
        self::assertSame('Something New', $fixture[0]->getEntree());
        self::assertSame('Something New', $fixture[0]->getSorties());
        self::assertSame('Something New', $fixture[0]->getSolde());
        self::assertSame('Something New', $fixture[0]->getObservation());
    }

    public function testRemove(): void
    {
        $this->markTestIncomplete();
        $fixture = new BrouillardCaisse();
        $fixture->setNumero('Value');
        $fixture->setDate('Value');
        $fixture->setLibelles('Value');
        $fixture->setTiers('Value');
        $fixture->setEntree('Value');
        $fixture->setSorties('Value');
        $fixture->setSolde('Value');
        $fixture->setObservation('Value');

        $this->manager->persist($fixture);
        $this->manager->flush();

        $this->client->request('GET', sprintf('%s%s', $this->path, $fixture->getId()));
        $this->client->submitForm('Delete');

        self::assertResponseRedirects('/brouillard/caisse/');
        self::assertSame(0, $this->repository->count([]));
    }
}
