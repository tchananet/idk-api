<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240628164912 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE brouillard_caisse (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, numero INTEGER DEFAULT NULL, date DATETIME DEFAULT NULL, libelles VARCHAR(255) NOT NULL, tiers VARCHAR(255) NOT NULL, entree INTEGER DEFAULT NULL, sorties INTEGER DEFAULT NULL, solde NUMERIC(9, 2) DEFAULT NULL, observation CLOB NOT NULL)');
        $this->addSql('CREATE TABLE facture_produit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, facture_id INTEGER DEFAULT NULL, produit_id INTEGER DEFAULT NULL, quantite INTEGER NOT NULL, prix_unitaire NUMERIC(20, 2) NOT NULL, total NUMERIC(20, 2) NOT NULL, observation CLOB DEFAULT NULL, CONSTRAINT FK_61424D7E7F2DEE08 FOREIGN KEY (facture_id) REFERENCES facture (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_61424D7EF347EFB FOREIGN KEY (produit_id) REFERENCES produit (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE INDEX IDX_61424D7E7F2DEE08 ON facture_produit (facture_id)');
        $this->addSql('CREATE INDEX IDX_61424D7EF347EFB ON facture_produit (produit_id)');
        $this->addSql('CREATE TABLE inventaire (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, description VARCHAR(255) NOT NULL, entree INTEGER NOT NULL, sortie INTEGER NOT NULL, si INTEGER NOT NULL, sf INTEGER NOT NULL, observation CLOB NOT NULL)');
        $this->addSql('CREATE TABLE produit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, stock_id_id INTEGER DEFAULT NULL, nom VARCHAR(255) DEFAULT NULL, sku VARCHAR(255) NOT NULL, prix_unitaire NUMERIC(20, 2) DEFAULT NULL, categorie VARCHAR(255) DEFAULT NULL, CONSTRAINT FK_29A5EC27E35482A6 FOREIGN KEY (stock_id_id) REFERENCES stock (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_29A5EC27F9038C4 ON produit (sku)');
        $this->addSql('CREATE INDEX IDX_29A5EC27E35482A6 ON produit (stock_id_id)');
        $this->addSql('DROP TABLE brouillarddecaisse');
        $this->addSql('DROP TABLE integer');
        $this->addSql('CREATE TEMPORARY TABLE __temp__client AS SELECT id, nom, compte_client, adresse, telephone FROM client');
        $this->addSql('DROP TABLE client');
        $this->addSql('CREATE TABLE client (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, telephone VARCHAR(20) NOT NULL)');
        $this->addSql('INSERT INTO client (id, nom, prenom, adresse, telephone) SELECT id, nom, compte_client, adresse, telephone FROM __temp__client');
        $this->addSql('DROP TABLE __temp__client');
        $this->addSql('CREATE TEMPORARY TABLE __temp__facture AS SELECT id, client_id FROM facture');
        $this->addSql('DROP TABLE facture');
        $this->addSql('CREATE TABLE facture (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, client_id INTEGER NOT NULL, moyen_paiement VARCHAR(20) NOT NULL, date DATETIME NOT NULL, numero_facture VARCHAR(20) NOT NULL, CONSTRAINT FK_FE86641019EB6921 FOREIGN KEY (client_id) REFERENCES client (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO facture (id, client_id) SELECT id, client_id FROM __temp__facture');
        $this->addSql('DROP TABLE __temp__facture');
        $this->addSql('CREATE INDEX IDX_FE86641019EB6921 ON facture (client_id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_FE86641038D27AB1 ON facture (numero_facture)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE brouillarddecaisse (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, numero INTEGER NOT NULL, date DATE NOT NULL, libelle VARCHAR(255) NOT NULL COLLATE "BINARY", tiers VARCHAR(255) NOT NULL COLLATE "BINARY", entrees INTEGER NOT NULL, sortie INTEGER NOT NULL, solde INTEGER NOT NULL, observation CLOB NOT NULL COLLATE "BINARY")');
        $this->addSql('CREATE TABLE integer (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, description VARCHAR(255) NOT NULL COLLATE "BINARY", entree INTEGER NOT NULL, sortie INTEGER NOT NULL, si INTEGER NOT NULL, sf INTEGER NOT NULL, observation CLOB NOT NULL COLLATE "BINARY")');
        $this->addSql('DROP TABLE brouillard_caisse');
        $this->addSql('DROP TABLE facture_produit');
        $this->addSql('DROP TABLE inventaire');
        $this->addSql('DROP TABLE produit');
        $this->addSql('CREATE TEMPORARY TABLE __temp__client AS SELECT id, nom, prenom, adresse, telephone FROM client');
        $this->addSql('DROP TABLE client');
        $this->addSql('CREATE TABLE client (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) DEFAULT NULL, compte_client VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, telephone INTEGER NOT NULL)');
        $this->addSql('INSERT INTO client (id, nom, compte_client, adresse, telephone) SELECT id, nom, prenom, adresse, telephone FROM __temp__client');
        $this->addSql('DROP TABLE __temp__client');
        $this->addSql('CREATE TEMPORARY TABLE __temp__facture AS SELECT id, client_id FROM facture');
        $this->addSql('DROP TABLE facture');
        $this->addSql('CREATE TABLE facture (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, client_id INTEGER DEFAULT NULL, moyen_paiement_id_id INTEGER DEFAULT NULL, quantite INTEGER NOT NULL, designation VARCHAR(255) NOT NULL, valeur NUMERIC(10, 2) NOT NULL, prix_unitaire INTEGER NOT NULL, prix_total_ht NUMERIC(10, 2) NOT NULL, transport NUMERIC(10, 2) NOT NULL, tva NUMERIC(10, 2) NOT NULL, ir NUMERIC(10, 2) NOT NULL, total_ttc NUMERIC(10, 2) NOT NULL, CONSTRAINT FK_FE86641019EB6921 FOREIGN KEY (client_id) REFERENCES client (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_FE866410CD0608E4 FOREIGN KEY (moyen_paiement_id_id) REFERENCES moyen_paiement (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO facture (id, client_id) SELECT id, client_id FROM __temp__facture');
        $this->addSql('DROP TABLE __temp__facture');
        $this->addSql('CREATE INDEX IDX_FE86641019EB6921 ON facture (client_id)');
        $this->addSql('CREATE INDEX IDX_FE866410CD0608E4 ON facture (moyen_paiement_id_id)');
    }
}
