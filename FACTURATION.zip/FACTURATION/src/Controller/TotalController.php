<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Vente;
use App\Entity\Stock;
use DateTime;

class TotalController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/total', name: 'app_total')]
    public function index(): JsonResponse
    {

        $totals = [
            'today' => $this->calculateTotals('today'),
            'week' => $this->calculateTotals('week'),
            'month' => $this->calculateTotals('month'),
            'year' => $this->calculateTotals('year'),
        ];

        return new JsonResponse($totals);
    }

    private function calculateTotals(string $period): array
    {
        $dateRange = $this->getDateRange($period);

        $salesTotal = $this->calculateSum(Vente::class, 'amount', $dateRange['start'], $dateRange['end']);
        $expensesTotal = $this->calculateSum(Stock::class, 'Sorties', $dateRange['start'], $dateRange['end']);
        $netTotal = $salesTotal - $expensesTotal;

        return [
            'sales' => $salesTotal,
            'expenses' => $expensesTotal,
            'net' => $netTotal,
        ];
    }

    private function calculateSum(string $entityClass, string $field, DateTime $start, DateTime $end): float
    {
        $repository = $this->entityManager->getRepository($entityClass);
        $query = $repository->createQueryBuilder('e')
            ->select('SUM(e.' . $field . ')')
            ->where('e.Date >= :start')
            ->andWhere('e.Date <= :end')
            ->setParameter('start', $start)
            ->setParameter('end', $end)
            ->getQuery();

        return (float) $query->getSingleScalarResult();
    }

    private function getDateRange(string $period): array
    {
        $end = new DateTime();
        $start = clone $end;

        switch ($period) {
            case 'today':
                $start->setTime(0, 0);
                break;
            case 'week':
                $start->modify('cette semaine');
                break;
            case 'month':
                $start->modify('ce mois ci');
                break;
            case 'year':
                $start->modify('depuis le moi de janvier' . $end->format('Y'));
                break;
        }

        return ['start' => $start, 'end' => $end];
    }
}
