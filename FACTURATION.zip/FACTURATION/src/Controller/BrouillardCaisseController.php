<?php

namespace App\Controller;

use App\Entity\BrouillardCaisse;
use App\Form\BrouillardCaisseType;
use App\Repository\BrouillardCaisseRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/brouillardcaisse')]
class BrouillardCaisseController extends AbstractController
{
    #[Route('/', name: 'app_brouillard_caisse_index', methods: ['GET'])]
    public function index(BrouillardCaisseRepository $brouillardCaisseRepository, SerializerInterface $serializer): Response
    {
        $brouillardCaisses = $brouillardCaisseRepository->findAll();
        $jsonContent = $serializer->serialize($brouillardCaisses, 'json');

        return new Response($jsonContent, Response::HTTP_OK, ['Content-Type' => 'application/json']);
    }

    #[Route('/new', name: 'app_brouillard_caisse_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, ValidatorInterface $validator, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $brouillardCaisse = $serializer->deserialize($jsonData, BrouillardCaisse::class, 'json');
        
        // Validation
        $errors = $validator->validate($brouillardCaisse);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $brouillardCaisse->setNumero($brouillardCaisse->getNumero());
        $brouillardCaisse->setDate($brouillardCaisse->getDate());
        $brouillardCaisse->setLibelles($brouillardCaisse->getLibelles());
        $brouillardCaisse->setTiers($brouillardCaisse->getTiers());
        $brouillardCaisse->setEntree($brouillardCaisse->getEntree());
        $brouillardCaisse->setSorties($brouillardCaisse->getSorties());
        $brouillardCaisse->setSolde($brouillardCaisse->getSolde());
        $brouillardCaisse->setObservation($brouillardCaisse->getObservation());

        $entityManager->persist($brouillardCaisse);
        $entityManager->flush();

        return new Response('', Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_brouillard_caisse_show', methods: ['GET'])]
    public function show(BrouillardCaisse $brouillardCaisse, SerializerInterface $serializer): Response
    {
        $jsonContent = $serializer->serialize($brouillardCaisse, 'json');

        return new Response($jsonContent, Response::HTTP_OK, ['Content-Type' => 'application/json']);
    }

    #[Route('/{id}/edit', name: 'app_brouillard_caisse_edit', methods: ['PUT'])]
    public function edit(Request $request, BrouillardCaisse $brouillardCaisse, EntityManagerInterface $entityManager, ValidatorInterface $validator, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $updatedBrouillardCaisse = $serializer->deserialize($jsonData, BrouillardCaisse::class, 'json');
        
        // Validation
        $errors = $validator->validate($updatedBrouillardCaisse);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $brouillardCaisse->setNumero($updatedBrouillardCaisse->getNumero());
        $brouillardCaisse->setDate($updatedBrouillardCaisse->getDate());
        $brouillardCaisse->setLibelles($updatedBrouillardCaisse->getLibelles());
        $brouillardCaisse->setTiers($updatedBrouillardCaisse->getTiers());
        $brouillardCaisse->setEntree($updatedBrouillardCaisse->getEntree());
        $brouillardCaisse->setSorties($updatedBrouillardCaisse->getSorties());
        $brouillardCaisse->setSolde($updatedBrouillardCaisse->getSolde());
        $brouillardCaisse->setObservation($updatedBrouillardCaisse->getObservation());

        $entityManager->flush();

        return new Response('', Response::HTTP_OK);
    }

    #[Route('/{id}', name: 'app_brouillard_caisse_delete', methods: ['DELETE'])]
    public function delete(BrouillardCaisse $brouillardCaisse, EntityManagerInterface $entityManager): Response
    {
        $entityManager->remove($brouillardCaisse);
        $entityManager->flush();

        return new Response('', Response::HTTP_NO_CONTENT);
    }
}
