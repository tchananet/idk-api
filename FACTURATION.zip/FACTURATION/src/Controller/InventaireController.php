<?php

namespace App\Controller;

use App\Entity\Inventaire;
use App\Form\InventaireType;
use App\Repository\InventaireRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;

#[Route('/inventaire')]
class InventaireController extends AbstractController
{
    #[Route('/', name: 'app_inventaire_index', methods: ['GET'])]
    public function index(InventaireRepository $inventaireRepository, SerializerInterface $serializer): Response
    {
        $inventaire = $inventaireRepository->findAll();
        $data = $serializer->serialize($inventaire, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/new', name: 'app_inventaire_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        // Création d'un nouvel objet Client et attribution des données reçues
        $inventaire = new Inventaire();
        $inventaire->setDescription($data['Description']);
        $inventaire->setEntree($data['entree']);
        $inventaire->setSortie($data['sortie']);
        $inventaire->setSI($data['SI']);
        $inventaire->setSF($data['SF']);
        $inventaire->setObservation($data['Observation']);

        // Insertion de l'objet client dans la base de données
        $entityManager->persist($inventaire);
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec l'ID du nouveau client créé
        return $this->json(['description' => $inventaire->getDescription(), 'entrer' => $inventaire->getEntree(), 'sortie' => $inventaire->getSortie(),'SI' => $inventaire->getSI(), 'SF' => $inventaire->getSF(), 'Observation' => $inventaire->getObservation()], Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_inventaire_show', methods: ['GET'])]
    public function show(Inventaire $inventaire): Response
    {
        
            return $this->json([
                'id' => $inventaire->getId(),
                'description' => $inventaire->getDescription(),
                'entree' => $inventaire->getEntree(),
                'sortie' => $inventaire->getSortie(),
                'si' => $inventaire->getSI(),
                'sf' => $inventaire->getSF(),
                'observation' => $inventaire->getObservation(),
            ]);

    }

    #[Route('/{id}/edit', name: 'app_inventaire_edit', methods: ['PUT'])]
    public function edit(Request $request, Inventaire $inventaire, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        $inventaire = new Inventaire();
        $inventaire->setDescription($data['Description']);
        $inventaire->setEntree($data['entree']);
        $inventaire->setSortie($data['sortie']);
        $inventaire->setSI($data['SI']);
        $inventaire->setSF($data['SF']);
        $inventaire->setObservation($data['Observation']);
        
        // Mise à jour de l'inventaire dans la base de données
        $entityManager->flush();

        // Renvoi d'une réponse vide avec un code de statut HTTP 200 (OK)
        return $this->json(['message' => 'inventaire modifié avec succès']);
    }

    #[Route('/{id}', name: 'app_inventaire_delete', methods: ['DELETE'])]
    public function delete(Inventaire $inventaire, EntityManagerInterface $entityManager): Response
    {
        // Suppression de l'inventaire de la base de données
        $entityManager->remove($inventaire);
        $entityManager->flush();

        // Renvoi d'une réponse vide avec un code de statut HTTP 204 (No Content)
        return $this->json(['message' => 'Inventaire supprimer avec succès']);
    }
}
