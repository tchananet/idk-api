<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Vente;
use App\Entity\Stock;
use DateTime;

class RecentTransactionController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/recent/transaction', name: 'app_recent_transaction')]
    public function index(): JsonResponse
    {
        // Get the 10 most recent transactions
        $recentTransactions = $this->getRecentTransactions(10);

        return new JsonResponse($recentTransactions);
    }

    private function getRecentTransactions(int $limit): array
    {
        $sales = $this->entityManager->getRepository(Vente::class)->findBy([], ['date' => 'DESC'], $limit);
        $stocks = $this->entityManager->getRepository(Stock::class)->findBy([], ['Date' => 'DESC'], $limit);

        // Merge and sort by date
        $transactions = array_merge($this->formatSales($sales), $this->formatStocks($stocks));
        usort($transactions, function($a, $b) {
            return $b['date']->getTimestamp() - $a['date']->getTimestamp();
        });

        // Return only the top $limit transactions
        return array_slice($transactions, 0, $limit);
    }

    private function formatSales(array $sales): array
    {
        return array_map(function($sale) {
            return [
                'type' => 'sale',
                'nom' => $sale->getClientID(), // Assuming there is a getName() method
                'date' => $sale->getDate()->format('Y-m-d'), // Formatting date
                'montant' => $sale->getMontant(),
                'status' => $sale->getStatus(), // Assuming there is a getStatus() method
            ];
        }, $sales);
    }

    private function formatStocks(array $stocks): array
    {
        return array_map(function($stock) {
            return [
                'type' => 'stock',
                'nom' => $stock->getEntrees(), 
                'date' => $stock->getDate()->format('Y-m-d'), 
                'Montant' => $stock->getSorties(),
                'status' => $stock->getStatus(), // Assuming there is a getStatus() method
            ];
        }, $stocks);
    }
}
