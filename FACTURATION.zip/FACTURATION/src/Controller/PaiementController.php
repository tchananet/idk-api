<?php

namespace App\Controller;

use App\Entity\Paiement;
use App\Form\PaiementType;
use App\Repository\PaiementRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/paiement')]
class PaiementController extends AbstractController
{
    private $validator;

    public function __construct(ValidatorInterface $validator)
    {
        $this->validator = $validator;
    }

    #[Route('/', name: 'app_paiement_index', methods: ['GET'])]
    public function index(PaiementRepository $paiementRepository, SerializerInterface $serializer): Response
    {
        $paiements = $paiementRepository->findAll();
        $data = $serializer->serialize($paiements, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }
    
    #[Route('/new', name: 'app_paiement_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $paiement = $serializer->deserialize($jsonData, Paiement::class, 'json');

        // Validation des contraintes de l'entité Paiement
        $errors = $this->validator->validate($paiement);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->persist($paiement);
        $entityManager->flush();

        return new Response('', Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_paiement_show', methods: ['GET'])]
    public function show(Paiement $paiement, SerializerInterface $serializer): Response
    {
        $data = $serializer->serialize($paiement, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/{id}/edit', name: 'app_paiement_edit', methods: ['PUT'])]
    public function edit(Request $request, Paiement $paiement, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $serializer->deserialize($jsonData, Paiement::class, 'json', ['object_to_populate' => $paiement]);

        // Validation des contraintes de l'entité Paiement
        $errors = $this->validator->validate($paiement);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->flush();

        return new Response('', Response::HTTP_OK);
    }

    #[Route('/{id}', name: 'app_paiement_delete', methods: ['DELETE'])]
    public function delete(Paiement $paiement, EntityManagerInterface $entityManager): Response
    {
        $entityManager->remove($paiement);
        $entityManager->flush();

        return new Response('', Response::HTTP_NO_CONTENT);
    }
}
