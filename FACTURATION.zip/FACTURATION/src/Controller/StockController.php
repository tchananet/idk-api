<?php

namespace App\Controller;

use App\Entity\Stock;
use App\Form\StockType;
use App\Repository\StockRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/stock')]
class StockController extends AbstractController
{
    #[Route('/', name: 'app_stock_index', methods: ['GET'])]
    public function index(StockRepository $stockRepository, SerializerInterface $serializer): Response
    {
        $stocks = $stockRepository->findAll();
        $data = $serializer->serialize($stocks, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/new', name: 'app_stock_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
    {
        $jsonData = $request->getContent();
        $stock = $serializer->deserialize($jsonData, Stock::class, 'json');

        // Validation des contraintes de l'entité Stock
        $errors = $validator->validate($stock);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->persist($stock);
        $entityManager->flush();

        return new Response('', Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_stock_show', methods: ['GET'])]
    public function show(Stock $stock, SerializerInterface $serializer): Response
    {
        $data = $serializer->serialize($stock, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/{id}/edit', name: 'app_stock_edit', methods: ['PUT'])]
    public function edit(Request $request, Stock $stock, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
    {
        $jsonData = $request->getContent();
        $serializer->deserialize($jsonData, Stock::class, 'json', ['object_to_populate' => $stock]);

        // Validation des contraintes de l'entité Stock
        $errors = $validator->validate($stock);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->flush();

        return new Response('', Response::HTTP_OK);
    }

    #[Route('/{id}', name: 'app_stock_delete', methods: ['DELETE'])]
    public function delete(Stock $stock, EntityManagerInterface $entityManager): Response
    {
        $entityManager->remove($stock);
        $entityManager->flush();

        return new Response('', Response::HTTP_NO_CONTENT);
    }
}
