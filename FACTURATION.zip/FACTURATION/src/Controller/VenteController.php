<?php

namespace App\Controller;

use App\Entity\Vente;
use App\Repository\VenteRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/vente')]
class VenteController extends AbstractController
{
    #[Route('/', name: 'app_vente_index', methods: ['GET'])]
    public function index(VenteRepository $venteRepository, SerializerInterface $serializer): Response
    {
        $ventes = $venteRepository->findAll();
        $data = $serializer->serialize($ventes, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/new', name: 'app_vente_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
    {
        $jsonData = $request->getContent();
        $vente = $serializer->deserialize($jsonData, Vente::class, 'json');

        // Validation des contraintes de l'entité Vente
        $errors = $validator->validate($vente);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->persist($vente);
        $entityManager->flush();

        return new JsonResponse(['message' => 'Vente créée avec succès!', 'id' => $vente->getId()], Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_vente_show', methods: ['GET'])]
    public function show(Vente $vente, SerializerInterface $serializer): Response
    {
        $data = $serializer->serialize($vente, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/{id}', name: 'app_vente_edit', methods: ['PUT'])]
    public function edit(Request $request, Vente $vente, EntityManagerInterface $entityManager, SerializerInterface $serializer, ValidatorInterface $validator): Response
    {
        $jsonData = $request->getContent();
        $serializer->deserialize($jsonData, Vente::class, 'json', ['object_to_populate' => $vente]);

        // Validation des contraintes de l'entité Vente
        $errors = $validator->validate($vente);
        if (count($errors) > 0) {
            $errorsString = (string) $errors;
            return new Response($errorsString, Response::HTTP_BAD_REQUEST);
        }

        $entityManager->flush();

        return new JsonResponse(['message' => 'Vente mise à jour!']);
    }

    #[Route('/{id}', name: 'app_vente_delete', methods: ['DELETE'])]
    public function delete(Vente $vente, EntityManagerInterface $entityManager): Response
    {
        $entityManager->remove($vente);
        $entityManager->flush();

        return new JsonResponse(['message' => 'Vente supprimée']);
    }
}
