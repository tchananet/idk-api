<?php

namespace App\Controller;

use App\Entity\Client;
use App\Repository\ClientRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ClientController extends AbstractController
{
    #[Route('/clients', name: 'app_client_index', methods: ['GET'])]
    public function index(ClientRepository $clientRepository): Response
    {
        // Récupération de tous les clients depuis le repository
        $clients = $clientRepository->findAll();

        // Conversion des données des clients en format JSON
        $clientsJson = [];
        foreach ($clients as $client) {
            $clientsJson[] = [
                'id' => $client->getId(),
                'nom' => $client->getNom(),
                'prenom' => $client->getPrenom(),
                'Adresse' => $client->getAdresse(),
                'Telephone' => $client->getTelephone(),
            ];
        }

        // Renvoi de la réponse JSON contenant tous les clients
        return $this->json($clientsJson);
    }

    #[Route('/clients/new', name: 'app_client_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        // Création d'un nouvel objet Client et attribution des données reçues
        $client = new Client();
        $client->setNom($data['nom']);
        $client->setPrenom($data['Prenom']);
        $client->setAdresse($data['Adresse']);
        $client->setTelephone($data['Telephone']);

        // Insertion de l'objet client dans la base de données
        $entityManager->persist($client);
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec l'ID du nouveau client créé
        return $this->json(['id' => $client->getId(), 'nom' => $client->getNom(), 'Prenom' => $client->getPrenom(),'Adresse' => $client->getAdresse(), 'Telephone' => $client->getTelephone()], Response::HTTP_CREATED);
    }

    #[Route('/clients/{id}', name: 'app_client_show', methods: ['GET'])]
    public function show(Client $client): Response
    {
        // Renvoi des données du client demandé au format JSON
        return $this->json([
            'id' => $client->getId(),
            'nom' => $client->getNom(),
            'prenom' => $client->getPrenom(),
            'Adresse' => $client->getAdresse(),
            'Telephone' => $client->getTelephone(),
        ]);
    }

    #[Route('/clients/{id}/edit', name: 'app_client_edit', methods: ['PUT'])]
    public function edit(Request $request, Client $client, EntityManagerInterface $entityManager): Response
    {
        // Récupération des données JSON envoyées par le frontend
        $data = json_decode($request->getContent(), true);

        // Modification des propriétés du client selon les données reçues
        $client->setNom($data['nom']);
        $client->setPrenom($data['Prenom']);
        $client->setAdresse($data['Adresse']);
        $client->setTelephone($data['Telephone']);

        // Insertion des modifications dans la base de données
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec un message de succès
        return $this->json(['message' => 'Client modifié avec succès']);
    }

    #[Route('/clients/{id}', name: 'app_client_delete', methods: ['DELETE'])]
    public function delete(Client $client, EntityManagerInterface $entityManager): Response
    {
        // Suppression du client de la base de données
        $entityManager->remove($client);
        $entityManager->flush();

        // Renvoi d'une réponse JSON avec un message de succès
        return $this->json(['message' => 'Client supprimé avec succès']);
    }
}
