<?php

namespace App\Controller;

use App\Entity\MoyenPaiement;
use App\Form\MoyenPaiementType;
use App\Repository\MoyenPaiementRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractObjectNormalizer;

#[Route('/moyen/paiement')]
class MoyenPaiementController extends AbstractController
{
    #[Route('/', name: 'app_moyen_paiement_index', methods: ['GET'])]
    public function index(MoyenPaiementRepository $moyenPaiementRepository, SerializerInterface $serializer): Response
    {
        $moyenPaiements = $moyenPaiementRepository->findAll();
        $data = $serializer->serialize($moyenPaiements, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/new', name: 'app_moyen_paiement_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $moyenPaiement = $serializer->deserialize($jsonData, MoyenPaiement::class, 'json');

        $entityManager->persist($moyenPaiement);
        $entityManager->flush();

        return new Response('', Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'app_moyen_paiement_show', methods: ['GET'])]
    public function show(MoyenPaiement $moyenPaiement, SerializerInterface $serializer): Response
    {
        $data = $serializer->serialize($moyenPaiement, 'json', [
            AbstractObjectNormalizer::IGNORED_ATTRIBUTES => ['__initializer__', '__cloner__', '__isInitialized__'],
        ]);

        return new Response($data, 200, [
            'Content-Type' => 'application/json'
        ]);
    }

    #[Route('/{id}/edit', name: 'app_moyen_paiement_edit', methods: ['PUT'])]
    public function edit(Request $request, MoyenPaiement $moyenPaiement, EntityManagerInterface $entityManager, SerializerInterface $serializer): Response
    {
        $jsonData = $request->getContent();
        $serializer->deserialize($jsonData, MoyenPaiement::class, 'json', ['object_to_populate' => $moyenPaiement]);

        $entityManager->flush();

        return new Response('', Response::HTTP_OK);
    }

    #[Route('/{id}', name: 'app_moyen_paiement_delete', methods: ['DELETE'])]
    public function delete(MoyenPaiement $moyenPaiement, EntityManagerInterface $entityManager): Response
    {
        $entityManager->remove($moyenPaiement);
        $entityManager->flush();

        return new Response('', Response::HTTP_NO_CONTENT);
    }
}
