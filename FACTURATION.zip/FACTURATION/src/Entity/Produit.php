<?php

namespace App\Entity;

use App\Repository\ProduitRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProduitRepository::class)]
class Produit
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $Nom = null;

    #[ORM\Column(length: 255, unique: true)]
    private ?string $SKU = null;

    #[ORM\Column(type: Types::DECIMAL, precision: 20, scale: 2, nullable: true)]
    private ?string $Prix_Unitaire = null;

    #[ORM\ManyToOne]
    private ?Stock $Stock_id = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $Categorie = null;

    #[ORM\PrePersist]
    public function setSkuAutomatically(): void
    {
        $this->SKU = bin2hex(random_bytes(4)); // Génère un SKU de 8 caractères hexadécimaux
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->Nom;
    }

    public function setNom(?string $Nom): static
    {
        $this->Nom = $Nom;

        return $this;
    }

    public function getSku(): ?string
    {
        return $this->SKU;
    }

    public function getPrixUnitaire(): ?string
    {
        return $this->Prix_Unitaire;
    }

    public function setPrixUnitaire(?string $Prix_Unitaire): static
    {
        $this->Prix_Unitaire = $Prix_Unitaire;

        return $this;
    }

    public function getStockId(): ?Stock
    {
        return $this->Stock_id;
    }

    public function setStockId(?Stock $Stock_id): static
    {
        $this->Stock_id = $Stock_id;

        return $this;
    }

    public function getCategorie(): ?string
    {
        return $this->Categorie;
    }

    public function setCategorie(?string $Categorie): static
    {
        $this->Categorie = $Categorie;

        return $this;
    }
}
