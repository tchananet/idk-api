<?php

namespace App\Entity;

use App\Repository\BrouillardCaisseRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: BrouillardCaisseRepository::class)]
class BrouillardCaisse
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(nullable: true)]
    private ?int $Numero = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $Date = null;

    #[ORM\Column(length: 255)]
    private ?string $Libelles = null;

    #[ORM\Column(length: 255)]
    private ?string $Tiers = null;

    #[ORM\Column(nullable: true)]
    private ?int $Entree = null;

    #[ORM\Column(nullable: true)]
    private ?int $Sorties = null;

    #[ORM\Column(type: Types::DECIMAL, precision: 9, scale: 2, nullable: true)]
    private ?string $Solde = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $Observation = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumero(): ?int
    {
        return $this->Numero;
    }

    public function setNumero(?int $Numero): static
    {
        $this->Numero = $Numero;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(?\DateTimeInterface $Date): static
    {
        $this->Date = $Date;

        return $this;
    }

    public function getLibelles(): ?string
    {
        return $this->Libelles;
    }

    public function setLibelles(string $Libelles): static
    {
        $this->Libelles = $Libelles;

        return $this;
    }

    public function getTiers(): ?string
    {
        return $this->Tiers;
    }

    public function setTiers(string $Tiers): static
    {
        $this->Tiers = $Tiers;

        return $this;
    }

    public function getEntree(): ?int
    {
        return $this->Entree;
    }

    public function setEntree(?int $Entree): static
    {
        $this->Entree = $Entree;

        return $this;
    }

    public function getSorties(): ?int
    {
        return $this->Sorties;
    }

    public function setSorties(?int $Sorties): static
    {
        $this->Sorties = $Sorties;

        return $this;
    }

    public function getSolde(): ?string
    {
        return $this->Solde;
    }

    public function setSolde(?string $Solde): static
    {
        $this->Solde = $Solde;

        return $this;
    }

    public function getObservation(): ?string
    {
        return $this->Observation;
    }

    public function setObservation(string $Observation): static
    {
        $this->Observation = $Observation;

        return $this;
    }
}
