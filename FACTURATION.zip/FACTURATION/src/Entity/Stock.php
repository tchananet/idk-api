<?php

namespace App\Entity;

use App\Repository\StockRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: StockRepository::class)]
class Stock
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $Date = null;

    #[ORM\Column]
    private ?int $KIT_GPS = null;

    #[ORM\Column(length: 255)]
    private ?string $Beneficiaire = null;

    #[ORM\Column]
    private ?int $Entrees = null;

    #[ORM\Column]
    private ?int $Sorties = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $Observation = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(\DateTimeInterface $Date): static
    {
        $this->Date = $Date;

        return $this;
    }

    public function getKITGPS(): ?int
    {
        return $this->KIT_GPS;
    }

    public function setKITGPS(int $KIT_GPS): static
    {
        $this->KIT_GPS = $KIT_GPS;

        return $this;
    }

    public function getBeneficiaire(): ?string
    {
        return $this->Beneficiaire;
    }

    public function setBeneficiaire(string $Beneficiaire): static
    {
        $this->Beneficiaire = $Beneficiaire;

        return $this;
    }

    public function getEntrees(): ?int
    {
        return $this->Entrees;
    }

    public function setEntrees(int $Entrees): static
    {
        $this->Entrees = $Entrees;

        return $this;
    }

    public function getSorties(): ?int
    {
        return $this->Sorties;
    }

    public function setSorties(int $Sorties): static
    {
        $this->Sorties = $Sorties;

        return $this;
    }

    public function getObservation(): ?string
    {
        return $this->Observation;
    }

    public function setObservation(string $Observation): static
    {
        $this->Observation = $Observation;

        return $this;
    }
}
