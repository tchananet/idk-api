<?php

namespace App\Form;

use App\Entity\BrouillardCaisse;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BrouillardCaisseType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('Numero')
            ->add('Date', null, [
                'widget' => 'single_text',
            ])
            ->add('Libelles')
            ->add('Tiers')
            ->add('Entree')
            ->add('Sorties')
            ->add('Solde')
            ->add('Observation')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => BrouillardCaisse::class,
        ]);
    }
}
