<?php

namespace App\Form;

use App\Entity\Client;
use App\Entity\Vente;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class VenteType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('Date', null, [
                'widget' => 'single_text',
            ])
            ->add('Telephone')
            ->add('Localisation')
            ->add('Immatriculation')
            ->add('Kit_GPS')
            ->add('Numero_Puce')
            ->add('IMEI')
            ->add('Vendeur')
            ->add('Type_Vente')
            ->add('Quantite')
            ->add('Montant')
            ->add('Avance')
            ->add('Reliquat')
            ->add('Observation')
            ->add('ClientID', EntityType::class, [
                'class' => Client::class,
                'choice_label' => 'id',
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Vente::class,
        ]);
    }
}
