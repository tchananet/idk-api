<?php

namespace App\Form;

use App\Entity\Brouillarddecaisse;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BrouillarddecaisseType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('Numero')
            ->add('Date', null, [
                'widget' => 'single_text',
            ])
            ->add('Libelle')
            ->add('Tiers')
            ->add('Entrees')
            ->add('Sortie')
            ->add('Solde')
            ->add('Observation')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Brouillarddecaisse::class,
        ]);
    }
}
